package com.ust.EComApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EComApplicationTests {

	@Test
	void contextLoads() {
	}

}
